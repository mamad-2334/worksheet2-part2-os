#ifndef IO_H
#define IO_H

#include "types.h"

u8int  inb(u16int port);
void   outb(u16int port, u8int value);

#endif
