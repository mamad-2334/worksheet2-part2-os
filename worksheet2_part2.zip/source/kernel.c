#include "types.h"
#include "framebuffer.h"
#include "keyboard.h"

#define NULL ((void*)0)

// =========================
// Utility: strlen
// =========================
static u32int k_strlen(const char *s)
{
    u32int n = 0;
    while (s[n]) n++;
    return n;
}

// =========================
// Utility: strcmp
// =========================
static int k_strcmp(const char *a, const char *b)
{
    while (*a && *b && *a == *b) {
        a++;
        b++;
    }
    return (unsigned char)*a - (unsigned char)*b;
}

// =========================
// Read a full line using keyboard_read_char()
// =========================
static void k_readline(char *buffer, u32int max)
{
    u32int i = 0;

    while (1) {
        char c = keyboard_read_char();

        // ENTER
        if (c == '\n') {
            write_char('\n');
            buffer[i] = 0;
            return;
        }

        // BACKSPACE
        if (c == '\b') {
            if (i > 0) {
                i--;
                write_char('\b');
            }
            continue;
        }

        // REGULAR CHAR
        if (i < max - 1) {
            buffer[i++] = c;
            write_char(c);
        }
    }
}

// =========================
// COMMAND HANDLERS
// =========================
void cmd_help(char *args)
{
    framebuffer_write("Commands:\n");
    framebuffer_write("  help      - Show this message\n");
    framebuffer_write("  echo TEXT - Print text\n");
    framebuffer_write("  clear     - Clear the screen\n");
    framebuffer_write("  version   - Show OS version\n");
    framebuffer_write("  shutdown  - Halt CPU\n");
}

void cmd_echo(char *args)
{
    if (args == NULL || *args == '\0') {
        framebuffer_write("Usage: echo <text>\n");
        return;
    }
    framebuffer_write(args);
    write_char('\n');
}

void cmd_clear(char *args)
{
    framebuffer_clear();
}

void cmd_version(char *args)
{
    framebuffer_write("MyOS version 0.1 (Worksheet 2 + 3)\n");
}

void cmd_shutdown(char *args)
{
    framebuffer_write("System halted.\n");
    while (1) { __asm__("hlt"); }
}

// =========================
// COMMAND TABLE
// =========================
struct command {
    const char *name;
    void (*func)(char *args);
};

static struct command commands[] = {
    { "help",     cmd_help     },
    { "echo",     cmd_echo     },
    { "clear",    cmd_clear    },
    { "version",  cmd_version  },
    { "shutdown", cmd_shutdown },
};

static const u32int COMMAND_COUNT = sizeof(commands) / sizeof(commands[0]);

// =========================
// COMMAND EXECUTION
// =========================
static void execute_command(char *line)
{
    // split into command + args
    char *cmd = line;
    while (*line && *line != ' ')
        line++;

    char *args = NULL;
    if (*line == ' ') {
        *line = 0;
        args = line + 1;
    }

    // search table
    for (u32int i = 0; i < COMMAND_COUNT; i++) {
        if (k_strcmp(cmd, commands[i].name) == 0) {
            commands[i].func(args);
            return;
        }
    }

    framebuffer_write("Unknown command: ");
    framebuffer_write(cmd);
    write_char('\n');
}

// =========================
// KERNEL MAIN
// =========================
void kernel_main(void)
{
    framebuffer_clear();
    framebuffer_write("Kernel is running!\n");
    framebuffer_write("Terminal ready. Type 'help'.\n");

    keyboard_install();

    char buffer[128];

    while (1) {
        framebuffer_write("myos> ");
        k_readline(buffer, sizeof(buffer));
        execute_command(buffer);
    }
}
