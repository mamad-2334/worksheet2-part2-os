# Operating Systems Worksheet 1

This repository contains my code for Worksheet 1 (Assembly + C).

## How to build

Run:

make

## How to run

### Task 1 programs
Run:


You will see output from:
- asm_main
- asm_main2

### Task 2 programs
Run:


You will see:
- sum of array 1..100
- prompt for range sum
- prompt for name repetition

---

## File structure


## Description of files

**task1.asm**  
Implements `asm_main` that adds two numbers and returns the result.

**task1_2.asm**  
Implements `asm_main2`, adding two integers from data section.

**task2_array.asm**  
Creates array 1..100 and sums it using assembly loops.

**task2_range.asm**  
Implements `range_sum(a,b)` entirely in assembler with validation.

**task2_name.asm**  
Calls C `puts()` from assembler to print a name N times.

**driver.c**  
Main C program that calls all assembler functions and handles user input.

---

## Screenshots to include in submission
Add screenshots of:

- Running `ls` showing your files
- Running `make`
- Running `./task1`
- Running `./task2`
- GitHub commits (evidence the repo is yours)

---

## Notes
All code in this repo follows 32-bit assembly using NASM with `-m32` GCC on csctcloud.
