#include "keyboard.h"
#include "io.h"
#include "framebuffer.h"

#define KEYBOARD_DATA_PORT   0x60
#define KEYBOARD_STATUS_PORT 0x64

/* Simple US QWERTY keymap for scan codes 0–58 */
static const char keymap[128] = {
    0,  27, '1','2','3','4','5','6','7','8','9','0','-','=', '\b',
    '\t',
    'q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0,
    'a','s','d','f','g','h','j','k','l',';','\'','`',
    0,
    '\\','z','x','c','v','b','n','m',',','.','/',
    0,
    '*',
    0,
    ' ',
};

char keyboard_read_char(void)
{
    while (1) {
        if (inb(KEYBOARD_STATUS_PORT) & 1) {
            u8int sc = inb(KEYBOARD_DATA_PORT);

            // ignore releases
            if (sc & 0x80) continue;

            if (sc < 128) {
                char c = keymap[sc];
                if (c != 0)
                    return c;
            }
        }
    }
}

void keyboard_install(void)
{
    framebuffer_write("Keyboard driver initialised.\n");
}
