#include "framebuffer.h"
#include "io.h"

#define FB_ADDRESS 0xB8000
#define FB_WIDTH   80
#define FB_HEIGHT  25

static volatile u16int *fb = (u16int*)FB_ADDRESS;
static u16int cursor_row = 0;
static u16int cursor_col = 0;
static u8int  fb_color   = 0x0F;  // white on black

static void fb_move_cursor(void)
{
    u16int pos = cursor_row * FB_WIDTH + cursor_col;

    outb(0x3D4, 14);
    outb(0x3D5, (pos >> 8) & 0xFF);
    outb(0x3D4, 15);
    outb(0x3D5, pos & 0xFF);
}

static void fb_scroll_if_needed(void)
{
    if (cursor_row < FB_HEIGHT)
        return;

    // scroll everything up by 1 line
    for (u32int row = 1; row < FB_HEIGHT; row++) {
        for (u32int col = 0; col < FB_WIDTH; col++) {
            fb[(row - 1) * FB_WIDTH + col] = fb[row * FB_WIDTH + col];
        }
    }

    // clear last line
    for (u32int col = 0; col < FB_WIDTH; col++) {
        fb[(FB_HEIGHT - 1) * FB_WIDTH + col] = (fb_color << 8) | ' ';
    }

    cursor_row = FB_HEIGHT - 1;
    cursor_col = 0;
}

void framebuffer_clear(void)
{
    for (u32int row = 0; row < FB_HEIGHT; row++) {
        for (u32int col = 0; col < FB_WIDTH; col++) {
            fb[row * FB_WIDTH + col] = (fb_color << 8) | ' ';
        }
    }
    cursor_row = 0;
    cursor_col = 0;
    fb_move_cursor();
}

void write_char(char c)
{
    if (c == '\n') {
        cursor_col = 0;
        cursor_row++;
        fb_scroll_if_needed();
        fb_move_cursor();
        return;
    }

    if (c == '\b') {
        if (cursor_col > 0) {
            cursor_col--;
        } else if (cursor_row > 0) {
            cursor_row--;
            cursor_col = FB_WIDTH - 1;
        }
        fb[cursor_row * FB_WIDTH + cursor_col] = (fb_color << 8) | ' ';
        fb_move_cursor();
        return;
    }

    fb[cursor_row * FB_WIDTH + cursor_col] = (fb_color << 8) | c;
    cursor_col++;
    if (cursor_col >= FB_WIDTH) {
        cursor_col = 0;
        cursor_row++;
    }
    fb_scroll_if_needed();
    fb_move_cursor();
}

void framebuffer_write(const char *s)
{
    while (*s) {
        write_char(*s++);
    }
}
