#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H

#include "types.h"

void framebuffer_clear(void);
void framebuffer_write(const char *s);
void write_char(char c);

#endif
