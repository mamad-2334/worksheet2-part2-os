#ifndef KEYBOARD_H
#define KEYBOARD_H

#include "types.h"

char keyboard_read_char(void);
void keyboard_install(void);

#endif
